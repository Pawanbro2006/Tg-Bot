<h1 align="center"><b> ❤️❤️  Hector  ❤️❤️</b></h1>

<h4 align="center">A Powerful, Smart And Simple Group Manager <br> ... Written with AioGram , Pyrogram and Telethon...</h4>
<p align='center'>
  <a href="https://www.python.org/" alt="made-with-python"> <img src="https://img.shields.io/badge/Made%20with-Python-1f425f.svg?style=flat-square&logo=python&color=blue" /> </a>
  <p align="center"><a href="https://t.me/Ezila_Updates"><img src="https://telegra.ph/file/3dc0815a6c1bde76a5108.jpg" width="400"></a></p>
<p align="center">
  <a href="https://github.com/sadew451/graphs/commit-activity" alt="Maintenance"> <img src="https://img.shields.io/badge/Maintained%3F-yes-green.svg?style=flat-square" /> </a>
</p>

[![Tutorial](https://yt-embed.herokuapp.com/embed?v=9vYgMk2k-dQ)](https://youtu.be/9vYgMk2k-dQ)

☆ Video by [SLSADEW BRO](https://www.youtube.com/channel/UCdSBUUQ1v0_IIElBR_1B72w) ☆


# 2 Branches available. this is main brach. swith advaced fr all fetures

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/sadew451/HectorBot)


## New version Avaiilable on Telegram as [SDBOTs In͏i͏f͏i͏n͏i͏t͏y͏](https://t.me/SDBOTs_inifinity)
## Ezilax-Bot is the latest

## 👉My Updates Channel [EzilaXUpdates](https://t.me/Ezila_Updates)

# ❤️ Support
<a href="https://t.me/Ezila_Support"><img src="https://img.shields.io/badge/Join-Telegram%20Channel-red.svg?logo=Telegram"></a>
<a href="https://t.me/Ezila_Updates"><img src="https://img.shields.io/badge/Join-Telegram%20Group-blue.svg?logo=telegram"></a>

## Credits ❤️

 - Uniborg
 - Telethon
 - Pyrogram
 - Skylee
 - emilia

## Special Credits

- [sadew](https://github.com/sadew451): Dev
- [SDBOTs 𝐈𝐧𝐢𝐟𝐢𝐧𝐢𝐭𝐲](https://t.me/SDBOTs_inifinity)

Anything missing kindly let us know at [Ezila Support](https://t.me/Ezila_Updates) or simply submit a pull request on the readme.

Should any be missing kindly let us know at [SDBOTs In͏i͏f͏i͏n͏i͏t͏y͏](https://t.me/SDBOTs_inifinity) or simply submit a pull request on the readme.

## EzilaXbot the telegram Bot Project
The Advanced Branch (For PRO's)
## Devs & Contributors

#### • SADEW JAYASEKARA    »»  <a href="https://github.com/sadew451" alt="sadew451"> <img src="https://img.shields.io/badge/sadew451-107D8D?logo=github" /></a> (DEV) 
#### • Damantha Jasingha    »»  <a href="https://github.com/damantha126" alt="damantha126"> <img src="https://img.shields.io/badge/damantha126-107D8D?logo=github" /></a> (DEV)

## SDBots(advvanced)

## Special Credits
- [sadew](https://github.com/sadew451) - A Co-Developer of Project ❤️
- [Damantha](https://github.com/Damantha126) - A Co-Developer of Project ❤️
- [SDBOTs In͏i͏f͏i͏n͏i͏t͏y͏](https://t.me/SDBOTs_inifinity) - Main Updates Channel ⭐️
- [TeamSDBOTs](https://github.com/TeamSDBOTs) - Our Team 🌟


